/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_postmeta`; */
/* PRE_TABLE_NAME: `1676453756_wp_postmeta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1676453756_wp_postmeta` ( `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `post_id` bigint(20) unsigned NOT NULL DEFAULT 0, `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL, `meta_value` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL, PRIMARY KEY (`meta_id`), KEY `post_id` (`post_id`), KEY `meta_key` (`meta_key`(191))) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1676453756_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES (1,2,'_wp_page_template','default'),(2,3,'_wp_page_template','default'),(4,1,'_edit_lock','1675847679:1'),(5,8,'_edit_lock','1676453702:1'),(10,11,'_menu_item_type','taxonomy'),(11,11,'_menu_item_menu_item_parent',0),(12,11,'_menu_item_object_id',3),(13,11,'_menu_item_object','category'),(14,11,'_menu_item_target',''),(15,11,'_menu_item_classes','a:1:{i:0;s:0:\"\";}'),(16,11,'_menu_item_xfn',''),(17,11,'_menu_item_url',''),(23,3,'_edit_lock','1675848237:1');
