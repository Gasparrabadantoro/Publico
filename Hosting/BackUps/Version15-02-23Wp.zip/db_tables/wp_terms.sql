/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_terms`; */
/* PRE_TABLE_NAME: `1676453756_wp_terms`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1676453756_wp_terms` ( `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT, `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '', `term_group` bigint(10) NOT NULL DEFAULT 0, PRIMARY KEY (`term_id`), KEY `slug` (`slug`(191)), KEY `name` (`name`(191))) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1676453756_wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES (1,'Uncategorised','uncategorised',0),(2,'fork','fork',0),(3,'Carnes','carnecita',0),(4,'Principal','principal',0);
