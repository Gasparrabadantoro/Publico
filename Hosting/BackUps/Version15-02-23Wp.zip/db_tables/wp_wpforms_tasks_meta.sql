/* CUSTOM VARS START */
/* REAL_TABLE_NAME: `wp_wpforms_tasks_meta`; */
/* PRE_TABLE_NAME: `1676453756_wp_wpforms_tasks_meta`; */
/* CUSTOM VARS END */

CREATE TABLE IF NOT EXISTS `1676453756_wp_wpforms_tasks_meta` ( `id` bigint(20) NOT NULL AUTO_INCREMENT, `action` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL, `data` longtext COLLATE utf8mb4_unicode_ci NOT NULL, `date` datetime NOT NULL, PRIMARY KEY (`id`)) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
INSERT INTO `1676453756_wp_wpforms_tasks_meta` (`id`, `action`, `data`, `date`) VALUES (1,'wpforms_process_forms_locator_scan','W10=','2023-02-08 08:35:52'),(3,'wpforms_admin_addons_cache_update','W10=','2023-02-08 08:35:54'),(4,'wpforms_admin_builder_templates_cache_update','W10=','2023-02-08 08:35:54'),(7,'wpforms_process_forms_locator_scan','W10=','2023-02-15 09:27:10');
